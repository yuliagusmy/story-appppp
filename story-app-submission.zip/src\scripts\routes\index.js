import Router from './router.js';
import routes from './routes.js';

const router = new Router(routes);

export default router;